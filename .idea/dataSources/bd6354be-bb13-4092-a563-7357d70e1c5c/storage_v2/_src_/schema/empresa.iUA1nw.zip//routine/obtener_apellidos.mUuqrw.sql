create
    definer = root@localhost function obtener_apellidos(dni varchar(10)) returns varchar(255)
BEGIN
    DECLARE apellidos VARCHAR(255); -- Declara una variable local para almacenar los apellidos

    SELECT Apellidos INTO apellidos
    FROM CLIENTES1
    WHERE DNI = dni
    LIMIT 1;

    RETURN apellidos; -- Devuelve el valor
END;

