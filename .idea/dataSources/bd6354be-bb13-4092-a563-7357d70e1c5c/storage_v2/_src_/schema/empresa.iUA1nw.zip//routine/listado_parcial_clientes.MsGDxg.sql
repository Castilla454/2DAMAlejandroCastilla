create
    definer = root@localhost procedure listado_parcial_clientes(IN in_dni char(9), INOUT inout_long int)
BEGIN
	DECLARE apell VARCHAR(32) DEFAULT NULL;
	SELECT APELLIDOS FROM clientes WHERE DNI = in_dni INTO apell;
	SET inout_long = inout_long + LENGTH(apell);
	SELECT DNI, APELLIDOS FROM CLIENTES
		WHERE APELLIDOS <= apell ORDER BY APELLIDOS;
END;

